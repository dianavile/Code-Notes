# HTML elements

1. `<mark>` => highlight text.
2. `<blockquote>` => for blockquote. Can have the cite attribute.
3. `<q>` => inline quote. Most browser will add quotation marks around text inside <q> tags. Can have the cite attribute.
4. `<footer>` => inside a blockquote element at the end of it will add the blockquote footer preceded by a wide hyphen.
5. `<cite>` 