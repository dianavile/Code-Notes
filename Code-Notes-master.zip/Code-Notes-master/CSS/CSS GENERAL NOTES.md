# **CSS GENERAL NOTES**

## **Overriding in CSS** :hand:

- **Overriding in a _descending_ order**
**!important** (_override all_) > **Inline Style** > **id** > **Subsequent Selector**

- :star: **Basically, the closer the style rule is to an element, the more specific it is. **