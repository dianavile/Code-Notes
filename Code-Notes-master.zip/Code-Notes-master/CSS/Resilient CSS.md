# Resilient CSS-Description

A video series ( 7 episodes) on how resilient CSS is and how to use new properties on every browser on the earth to make most of our users have similar or even the same experience with your websites.
It is presented by [Jen Simmons](https://twitter.com/jensimmons?lang=en).

Initial notes:

1. Can I use
2. It is ok for some property being ignored by some unspported browsers.
3. override
4. feature query
5. feature query support / "not"
6. working another way out. / doesn't deserve any of the above and there are another way out.