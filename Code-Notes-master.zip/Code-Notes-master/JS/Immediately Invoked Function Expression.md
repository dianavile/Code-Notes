# Immediately Invoked Function Expression

- A good [article to introduce IIFE](http://adripofjavascript.com/blog/drips/an-introduction-to-iffes-immediately-invoked-function-expressions.html).