# JavaScript-[Data Types-JS](-Data-Types-JavaScript)
_Source: Data Types JavaScript - Udacity Front End Web Development Nanodegree_

WORKING ON IT!
### Table Of Contents:
- a. Data and Data Types
- b. Define and manipulate data types
- c. Numbers
- d. Booleans
- e. Undefined
- f. Null
- g. 
- h. 

### a. DATA and Data Types
- `Data` and `Data Types` are the _building blocks of every programming language_.
  1) They help to __organize information__.
  2) They determine __how programs will run__.
  
### b. Define and manipulate data types

### c. Numbers

### d. Booleans

### e. Undefined

### f. Null

#### Resources 
- []()
