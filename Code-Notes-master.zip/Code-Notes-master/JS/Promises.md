# Promises Course Stages:

1. Wrapping.
2. Thening.
3. Catching.
4. Chaining.

# Promises States:

1. Fulfilled (Resolved). => The action related to the promise succeeded.
2. Rejected. => The action related to the promise failed.
3. Pending. => Promise has not yet fulfilled or rejected.
4. Settled. => Promise has either fulfilled or rejected.